/* ============================================================
   LUXE BEAUTY STUDIO - APPOINTMENT BOOKING ENGINE
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {
  initBookingForm();
});

function initBookingForm() {
  const form = document.getElementById('booking-form');
  const serviceSelect = document.getElementById('booking-service');
  const staffSelect = document.getElementById('booking-staff');
  const amountInput = document.getElementById('booking-amount');
  const resetBtn = document.getElementById('booking-reset');

  if (!form) return;

  // Populate Services Dropdown
  const services = getServicesList();
  if (serviceSelect && services.length) {
    serviceSelect.innerHTML = '<option value="">-- Select Luxury Service --</option>' +
      services.map(s => `<option value="${s.name}" data-price="${s.price}">[${s.category}] ${s.name} - ₹${s.price}</option>`).join('');
  }

  // Populate Staff Dropdown
  const staffMembers = getStaffList();
  if (staffSelect && staffMembers.length) {
    staffSelect.innerHTML = '<option value="Any Available Specialist">Any Available Specialist</option>' +
      staffMembers.map(st => `<option value="${st.name}">${st.name} (${st.role})</option>`).join('');
  }

  // Pre-select service if in URL query string
  const urlParams = new URLSearchParams(window.location.search);
  const preSelectedService = urlParams.get('service');
  if (preSelectedService && serviceSelect) {
    serviceSelect.value = preSelectedService;
    updateTotalAmount();
  }

  // Auto-calculate Total Amount on service change
  if (serviceSelect) {
    serviceSelect.addEventListener('change', updateTotalAmount);
  }

  function updateTotalAmount() {
    const selectedOpt = serviceSelect.options[serviceSelect.selectedIndex];
    if (selectedOpt && selectedOpt.dataset.price) {
      const price = parseFloat(selectedOpt.dataset.price);
      if (amountInput) {
        amountInput.value = `₹${price.toFixed(2)}`;
      }
    } else {
      if (amountInput) amountInput.value = '₹0.00';
    }
  }

  // Reset Form Action
  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      form.reset();
      if (amountInput) amountInput.value = '₹0.00';
      showToast('Form reset successfully', 'info');
    });
  }

  // Form Submit & Validation
  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const fullName = document.getElementById('booking-name').value.trim();
    const phone = document.getElementById('booking-phone').value.trim();
    const email = document.getElementById('booking-email').value.trim();
    const serviceName = serviceSelect ? serviceSelect.value : '';
    const staffName = staffSelect ? staffSelect.value : 'Any Available Specialist';
    const apptDate = document.getElementById('booking-date').value;
    const apptTime = document.getElementById('booking-time').value;
    const notes = document.getElementById('booking-notes') ? document.getElementById('booking-notes').value.trim() : '';

    // Validation
    if (!fullName) {
      showToast('Please enter your full name', 'error');
      document.getElementById('booking-name').focus();
      return;
    }
    if (!phone || phone.length < 7) {
      showToast('Please enter a valid phone number', 'error');
      document.getElementById('booking-phone').focus();
      return;
    }
    if (!email || !email.includes('@')) {
      showToast('Please enter a valid email address', 'error');
      document.getElementById('booking-email').focus();
      return;
    }
    if (!serviceName) {
      showToast('Please select a service', 'error');
      serviceSelect.focus();
      return;
    }
    if (!apptDate) {
      showToast('Please choose an appointment date', 'error');
      document.getElementById('booking-date').focus();
      return;
    }
    if (!apptTime) {
      showToast('Please select an appointment time', 'error');
      document.getElementById('booking-time').focus();
      return;
    }

    // Get selected service object for price
    const serviceObj = services.find(s => s.name === serviceName);
    const servicePrice = serviceObj ? serviceObj.price : 0;

    // Generate Unique Booking ID (e.g. LBS-2026-7841)
    const randomCode = Math.floor(1000 + Math.random() * 9000);
    const bookingId = `LBS-2026-${randomCode}`;

    const newBooking = {
      id: bookingId,
      fullName: fullName,
      phone: phone,
      email: email,
      service: serviceName,
      servicePrice: servicePrice,
      preferredStaff: staffName,
      date: apptDate,
      time: apptTime,
      notes: notes,
      status: 'confirmed',
      createdAt: new Date().toISOString()
    };

    // Save to LocalStorage
    addAppointment(newBooking);

    // Show Confirmation Modal
    showConfirmationModal(newBooking);

    // Reset Form
    form.reset();
    if (amountInput) amountInput.value = '$0.00';
  });
}

// Helpers
function getServicesList() {
  if (typeof DEFAULT_SERVICES !== 'undefined') return DEFAULT_SERVICES;
  try {
    return JSON.parse(localStorage.getItem('luxe_services')) || [];
  } catch(e) {
    return [];
  }
}

function getStaffList() {
  if (typeof DEFAULT_STAFF !== 'undefined') return DEFAULT_STAFF;
  try {
    return JSON.parse(localStorage.getItem('luxe_staff_members')) || [];
  } catch(e) {
    return [];
  }
}

// Confirmation Receipt Modal
function showConfirmationModal(booking) {
  let modal = document.getElementById('booking-success-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'booking-success-modal';
    modal.className = 'modal-backdrop';
    document.body.appendChild(modal);
  }

  modal.innerHTML = `
    <div class="modal-box text-center" style="max-width: 520px;">
      <button class="modal-close" onclick="closeBookingModal()">&times;</button>
      <div style="width: 70px; height: 70px; border-radius: 50%; background: var(--gold-light); border: 2px solid var(--gold-primary); display: flex; align-items: center; justify-content: center; margin: 0 auto 20px auto; color: var(--gold-primary); font-size: 2rem;">
        ✓
      </div>
      <span class="section-subtitle">Reservation Confirmed</span>
      <h3 style="font-size: 2rem; margin-bottom: 8px;">Thank You, ${booking.fullName}!</h3>
      <p style="font-size: 0.95rem; margin-bottom: 24px;">Your luxury pampering session has been reserved.</p>
      
      <div style="background: var(--bg-secondary); border: 1px dashed var(--gold-primary); border-radius: var(--radius-md); padding: 20px; text-align: left; margin-bottom: 24px; font-size: 0.9rem;">
        <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--border-subtle); padding-bottom: 10px; margin-bottom: 10px;">
          <span style="color: var(--text-muted);">Booking ID:</span>
          <strong style="color: var(--gold-primary); font-family: monospace; font-size: 1.1rem;">${booking.id}</strong>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
          <span style="color: var(--text-muted);">Service:</span>
          <strong>${booking.service}</strong>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
          <span style="color: var(--text-muted);">Specialist:</span>
          <strong>${booking.preferredStaff}</strong>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
          <span style="color: var(--text-muted);">Date & Time:</span>
          <strong>${booking.date} at ${booking.time}</strong>
        </div>
        <div style="display: flex; justify-content: space-between; border-top: 1px solid var(--border-subtle); padding-top: 10px; margin-top: 10px; font-size: 1.05rem;">
          <span>Total Amount:</span>
          <strong style="color: var(--gold-primary); font-family: var(--font-serif); font-size: 1.3rem;">₹${booking.servicePrice.toFixed(2)}</strong>
        </div>
      </div>

      <div style="display: flex; gap: 12px; justify-content: center;">
        <button onclick="closeBookingModal()" class="btn btn-gold">Done</button>
        <button onclick="window.print()" class="btn btn-outline">Print Receipt</button>
      </div>
    </div>
  `;

  setTimeout(() => modal.classList.add('active'), 10);
}

function closeBookingModal() {
  const modal = document.getElementById('booking-success-modal');
  if (modal) modal.classList.remove('active');
}

/* Custom Toast Notification */
function showToast(message, type = 'info') {
  let toastContainer = document.getElementById('toast-container');
  if (!toastContainer) {
    toastContainer = document.createElement('div');
    toastContainer.id = 'toast-container';
    toastContainer.style.cssText = 'position: fixed; bottom: 30px; left: 30px; z-index: 999999; display: flex; flex-direction: column; gap: 10px;';
    document.body.appendChild(toastContainer);
  }

  const toast = document.createElement('div');
  const bgColor = type === 'error' ? '#ef4444' : type === 'success' ? '#10b981' : '#c59b27';
  toast.style.cssText = `background: ${bgColor}; color: #ffffff; padding: 12px 24px; border-radius: 8px; font-size: 0.9rem; font-weight: 500; box-shadow: 0 10px 25px rgba(0,0,0,0.2); transition: all 0.3s ease; transform: translateY(20px); opacity: 0;`;
  toast.innerText = message;

  toastContainer.appendChild(toast);
  setTimeout(() => {
    toast.style.transform = 'translateY(0)';
    toast.style.opacity = '1';
  }, 10);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(-10px)';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}
