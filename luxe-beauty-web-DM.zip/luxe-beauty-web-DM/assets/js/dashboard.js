/* ============================================================
   LUXE BEAUTY STUDIO - STAFF DASHBOARD MANAGEMENT
   ============================================================ */

let currentTab = 'today';
let searchKeyword = '';
let dateFilter = '';
let serviceFilter = '';

document.addEventListener('DOMContentLoaded', () => {
  checkAuth();
  initDashboardHeader();
  initDashboardEvents();
  renderDashboard();
});

// Check if Staff is Logged In
function checkAuth() {
  const staffUserStr = localStorage.getItem(STORAGE_KEYS.STAFF_USER);
  if (!staffUserStr) {
    window.location.href = 'staff-login.html';
    return;
  }
  const user = JSON.parse(staffUserStr);
  const nameEl = document.getElementById('dash-staff-name');
  const roleEl = document.getElementById('dash-staff-role');
  if (nameEl) nameEl.innerText = user.name;
  if (roleEl) roleEl.innerText = user.role;
}

function initDashboardHeader() {
  const logoutBtn = document.getElementById('staff-logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      localStorage.removeItem(STORAGE_KEYS.STAFF_USER);
      showToast('Logged out successfully', 'info');
      setTimeout(() => {
        window.location.href = 'staff-login.html';
      }, 500);
    });
  }
}

function initDashboardEvents() {
  // Tab Switchers
  const tabBtns = document.querySelectorAll('.dash-tab-btn');
  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      tabBtns.forEach(b => b.classList.remove('active', 'btn-gold'));
      tabBtns.forEach(b => b.classList.add('btn-outline'));
      btn.classList.add('active', 'btn-gold');
      btn.classList.remove('btn-outline');
      currentTab = btn.getAttribute('data-tab');
      renderDashboard();
    });
  });

  // Search input
  const searchInput = document.getElementById('dash-search-input');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      searchKeyword = e.target.value.toLowerCase().trim();
      renderDashboard();
    });
  }

  // Date Filter
  const dateInput = document.getElementById('dash-date-filter');
  if (dateInput) {
    dateInput.addEventListener('change', (e) => {
      dateFilter = e.target.value;
      renderDashboard();
    });
  }

  // Service Filter Dropdown
  const serviceSelect = document.getElementById('dash-service-filter');
  if (serviceSelect) {
    const services = typeof DEFAULT_SERVICES !== 'undefined' ? DEFAULT_SERVICES : [];
    serviceSelect.innerHTML = '<option value="">All Services</option>' +
      services.map(s => `<option value="${s.name}">${s.name}</option>`).join('');

    serviceSelect.addEventListener('change', (e) => {
      serviceFilter = e.target.value;
      renderDashboard();
    });
  }

  // Reset Filters
  const resetFiltersBtn = document.getElementById('dash-reset-filters');
  if (resetFiltersBtn) {
    resetFiltersBtn.addEventListener('click', () => {
      searchKeyword = '';
      dateFilter = '';
      serviceFilter = '';
      if (searchInput) searchInput.value = '';
      if (dateInput) dateInput.value = '';
      if (serviceSelect) serviceSelect.value = '';
      renderDashboard();
    });
  }

  // New Booking Modal Trigger
  const addBookingBtn = document.getElementById('dash-add-booking-btn');
  if (addBookingBtn) {
    addBookingBtn.addEventListener('click', showAddBookingModal);
  }

  // Google Sheet Sync Modal Trigger
  const gsheetBtn = document.getElementById('dash-gsheet-btn');
  if (gsheetBtn) {
    gsheetBtn.addEventListener('click', showGoogleSheetModal);
  }
}

function renderDashboard() {
  const allAppointments = getAppointments();
  
  // Calculate Today's Date YYYY-MM-DD
  const todayStr = new Date().toISOString().split('T')[0];

  // Update Summary Counters
  const countToday = allAppointments.filter(a => a.date === todayStr && a.status !== 'cancelled').length;
  const countUpcoming = allAppointments.filter(a => a.date > todayStr && a.status === 'confirmed').length;
  const countCompleted = allAppointments.filter(a => a.status === 'completed').length;
  const countCancelled = allAppointments.filter(a => a.status === 'cancelled').length;
  const countCustomers = new Set(allAppointments.map(a => a.email.toLowerCase())).size;

  const elToday = document.getElementById('cnt-today');
  const elUpcoming = document.getElementById('cnt-upcoming');
  const elCompleted = document.getElementById('cnt-completed');
  const elCancelled = document.getElementById('cnt-cancelled');
  const elCustomers = document.getElementById('cnt-customers');

  if (elToday) elToday.innerText = countToday;
  if (elUpcoming) elUpcoming.innerText = countUpcoming;
  if (elCompleted) elCompleted.innerText = countCompleted;
  if (elCancelled) elCancelled.innerText = countCancelled;
  if (elCustomers) elCustomers.innerText = countCustomers;

  // Filter List based on Active Tab
  let filtered = [...allAppointments];

  if (currentTab === 'today') {
    filtered = filtered.filter(a => a.date === todayStr && a.status !== 'cancelled');
  } else if (currentTab === 'upcoming') {
    filtered = filtered.filter(a => (a.date > todayStr || a.date === todayStr) && a.status === 'confirmed');
  } else if (currentTab === 'completed') {
    filtered = filtered.filter(a => a.status === 'completed');
  } else if (currentTab === 'cancelled') {
    filtered = filtered.filter(a => a.status === 'cancelled');
  } else if (currentTab === 'customers') {
    renderCustomerList(allAppointments);
    return;
  }

  // Apply Search Keyword Filter
  if (searchKeyword) {
    filtered = filtered.filter(a => 
      a.fullName.toLowerCase().includes(searchKeyword) ||
      a.id.toLowerCase().includes(searchKeyword) ||
      a.phone.toLowerCase().includes(searchKeyword) ||
      a.email.toLowerCase().includes(searchKeyword) ||
      a.service.toLowerCase().includes(searchKeyword)
    );
  }

  // Apply Date Filter
  if (dateFilter) {
    filtered = filtered.filter(a => a.date === dateFilter);
  }

  // Apply Service Filter
  if (serviceFilter) {
    filtered = filtered.filter(a => a.service === serviceFilter);
  }

  renderAppointmentsTable(filtered);
}

// Render Appointments Table
function renderAppointmentsTable(list) {
  const container = document.getElementById('dash-table-container');
  if (!container) return;

  if (list.length === 0) {
    container.innerHTML = `
      <div style="text-align: center; padding: 60px 20px; color: var(--text-muted);">
        <p style="font-size: 1.1rem; margin-bottom: 8px;">No appointments found matching this view or filter.</p>
        <span style="font-size: 0.85rem;">Try adjusting search keywords or clearing filters.</span>
      </div>
    `;
    return;
  }

  container.innerHTML = `
    <div class="table-responsive">
      <table class="custom-table">
        <thead>
          <tr>
            <th>Booking ID</th>
            <th>Customer</th>
            <th>Service & Amount</th>
            <th>Specialist</th>
            <th>Date & Time</th>
            <th>Status</th>
            <th style="text-align: right;">Actions</th>
          </tr>
        </thead>
        <tbody>
          ${list.map(a => `
            <tr>
              <td><strong style="color: var(--gold-primary); font-family: monospace;">${a.id}</strong></td>
              <td>
                <div style="font-weight: 600;">${a.fullName}</div>
                <div style="font-size: 0.8rem; color: var(--text-muted);">${a.phone}</div>
              </td>
              <td>
                <div style="font-weight: 500;">${a.service}</div>
                <div style="font-size: 0.85rem; color: var(--gold-primary); font-weight: 600;">₹${(a.servicePrice || 0).toFixed(2)}</div>
              </td>
              <td>${a.preferredStaff || 'Unassigned'}</td>
              <td>
                <div>${a.date}</div>
                <div style="font-size: 0.8rem; color: var(--text-muted);">${a.time}</div>
              </td>
              <td>
                <span class="badge-status ${a.status}">${a.status}</span>
              </td>
              <td style="text-align: right; white-space: nowrap;">
                <button onclick="viewAppointmentDetails('${a.id}')" class="btn btn-sm btn-outline" style="padding: 4px 10px; font-size: 0.75rem;" title="View Details">View</button>
                <button onclick="showEditAppointmentModal('${a.id}')" class="btn btn-sm btn-outline" style="padding: 4px 10px; font-size: 0.75rem;" title="Edit Appointment">Edit</button>
                ${a.status !== 'completed' ? `<button onclick="markStatus('${a.id}', 'completed')" class="btn btn-sm btn-gold" style="padding: 4px 10px; font-size: 0.75rem;" title="Complete">Complete</button>` : ''}
                ${a.status !== 'cancelled' ? `<button onclick="markStatus('${a.id}', 'cancelled')" class="btn btn-sm" style="padding: 4px 10px; font-size: 0.75rem; background: rgba(239, 68, 68, 0.15); color: #ef4444; border: 1px solid rgba(239, 68, 68, 0.3);" title="Cancel">Cancel</button>` : ''}
                <button onclick="confirmDeleteAppointment('${a.id}')" class="btn btn-sm" style="padding: 4px 8px; font-size: 0.75rem; background: transparent; color: var(--text-muted);" title="Delete">&times;</button>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;
}

// Render Customer List Tab
function renderCustomerList(allAppointments) {
  const container = document.getElementById('dash-table-container');
  if (!container) return;

  // Group by email
  const customersMap = {};
  allAppointments.forEach(a => {
    const key = a.email.toLowerCase();
    if (!customersMap[key]) {
      customersMap[key] = {
        name: a.fullName,
        email: a.email,
        phone: a.phone,
        totalBookings: 0,
        totalSpent: 0,
        lastVisit: a.date
      };
    }
    customersMap[key].totalBookings += 1;
    if (a.status === 'completed' || a.status === 'confirmed') {
      customersMap[key].totalSpent += (a.servicePrice || 0);
    }
    if (a.date > customersMap[key].lastVisit) {
      customersMap[key].lastVisit = a.date;
    }
  });

  const list = Object.values(customersMap);

  container.innerHTML = `
    <div class="table-responsive">
      <table class="custom-table">
        <thead>
          <tr>
            <th>Customer Name</th>
            <th>Contact Details</th>
            <th>Total Bookings</th>
            <th>Total Spent</th>
            <th>Last Visit</th>
            <th style="text-align: right;">Action</th>
          </tr>
        </thead>
        <tbody>
          ${list.map(c => `
            <tr>
              <td><strong style="font-size: 0.95rem;">${c.name}</strong></td>
              <td>
                <div>${c.email}</div>
                <div style="font-size: 0.8rem; color: var(--text-muted);">${c.phone}</div>
              </td>
              <td><span style="font-weight: 600;">${c.totalBookings} visits</span></td>
              <td><strong style="color: var(--gold-primary); font-family: var(--font-serif); font-size: 1.1rem;">₹${c.totalSpent.toFixed(2)}</strong></td>
              <td>${c.lastVisit}</td>
              <td style="text-align: right;">
                <button onclick="filterByCustomer('${c.email}')" class="btn btn-sm btn-gold" style="padding: 4px 12px; font-size: 0.75rem;">View History</button>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;
}

function filterByCustomer(email) {
  currentTab = 'all';
  searchKeyword = email;
  renderDashboard();
}

// Actions
window.markStatus = function(id, newStatus) {
  updateAppointment(id, { status: newStatus });
  showToast(`Appointment ${id} marked as ${newStatus}!`, 'success');
  renderDashboard();
};

window.confirmDeleteAppointment = function(id) {
  if (confirm(`Are you sure you want to delete appointment ${id}? This action cannot be undone.`)) {
    deleteAppointment(id);
    showToast(`Appointment ${id} deleted`, 'info');
    renderDashboard();
  }
};

// View Appointment Modal
window.viewAppointmentDetails = function(id) {
  const appointments = getAppointments();
  const appt = appointments.find(a => a.id === id);
  if (!appt) return;

  let modal = document.getElementById('dash-action-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'dash-action-modal';
    modal.className = 'modal-backdrop';
    document.body.appendChild(modal);
  }

  modal.innerHTML = `
    <div class="modal-box" style="max-width: 520px;">
      <button class="modal-close" onclick="closeDashModal()">&times;</button>
      <span class="section-subtitle">Appointment Record</span>
      <h3 style="font-size: 1.8rem; margin-bottom: 20px;">${appt.id}</h3>

      <div style="display: flex; flex-direction: column; gap: 12px; font-size: 0.95rem; margin-bottom: 24px;">
        <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--border-subtle); padding-bottom: 8px;">
          <span style="color: var(--text-muted);">Customer Name:</span>
          <strong>${appt.fullName}</strong>
        </div>
        <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--border-subtle); padding-bottom: 8px;">
          <span style="color: var(--text-muted);">Phone & Email:</span>
          <div style="text-align: right;">
            <div>${appt.phone}</div>
            <div style="font-size: 0.8rem; color: var(--text-muted);">${appt.email}</div>
          </div>
        </div>
        <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--border-subtle); padding-bottom: 8px;">
          <span style="color: var(--text-muted);">Service:</span>
          <strong>${appt.service} (₹${(appt.servicePrice || 0).toFixed(2)})</strong>
        </div>
        <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--border-subtle); padding-bottom: 8px;">
          <span style="color: var(--text-muted);">Assigned Specialist:</span>
          <strong>${appt.preferredStaff}</strong>
        </div>
        <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--border-subtle); padding-bottom: 8px;">
          <span style="color: var(--text-muted);">Scheduled Date & Time:</span>
          <strong>${appt.date} at ${appt.time}</strong>
        </div>
        <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--border-subtle); padding-bottom: 8px;">
          <span style="color: var(--text-muted);">Status:</span>
          <span class="badge-status ${appt.status}">${appt.status}</span>
        </div>
        <div>
          <span style="color: var(--text-muted); display: block; margin-bottom: 4px;">Special Requests / Notes:</span>
          <div style="background: var(--bg-secondary); padding: 10px 14px; border-radius: var(--radius-sm); font-size: 0.88rem; font-style: italic;">
            ${appt.notes || 'No special requests provided.'}
          </div>
        </div>
      </div>

      <div style="display: flex; gap: 12px; justify-content: flex-end;">
        <button onclick="closeDashModal()" class="btn btn-outline">Close</button>
        <button onclick="showEditAppointmentModal('${appt.id}')" class="btn btn-gold">Edit Details</button>
      </div>
    </div>
  `;

  setTimeout(() => modal.classList.add('active'), 10);
};

// Edit Modal
window.showEditAppointmentModal = function(id) {
  const appointments = getAppointments();
  const appt = appointments.find(a => a.id === id);
  if (!appt) return;

  const services = typeof DEFAULT_SERVICES !== 'undefined' ? DEFAULT_SERVICES : [];
  const staffMembers = typeof DEFAULT_STAFF !== 'undefined' ? DEFAULT_STAFF : [];

  let modal = document.getElementById('dash-action-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'dash-action-modal';
    modal.className = 'modal-backdrop';
    document.body.appendChild(modal);
  }

  modal.innerHTML = `
    <div class="modal-box" style="max-width: 540px;">
      <button class="modal-close" onclick="closeDashModal()">&times;</button>
      <span class="section-subtitle">Update Appointment</span>
      <h3 style="font-size: 1.8rem; margin-bottom: 20px;">Edit ${appt.id}</h3>

      <form id="edit-appt-form" onsubmit="saveAppointmentEdits(event, '${appt.id}')">
        <div class="form-group">
          <label class="form-label">Customer Name</label>
          <input type="text" id="edit-name" class="form-control" value="${appt.fullName}" required>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
          <div class="form-group">
            <label class="form-label">Service</label>
            <select id="edit-service" class="form-control">
              ${services.map(s => `<option value="${s.name}" ${s.name === appt.service ? 'selected' : ''}>${s.name} (₹${s.price})</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Specialist</label>
            <select id="edit-staff" class="form-control">
              <option value="Any Available Specialist">Any Available Specialist</option>
              ${staffMembers.map(st => `<option value="${st.name}" ${st.name === appt.preferredStaff ? 'selected' : ''}>${st.name}</option>`).join('')}
            </select>
          </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
          <div class="form-group">
            <label class="form-label">Date</label>
            <input type="date" id="edit-date" class="form-control" value="${appt.date}" required>
          </div>
          <div class="form-group">
            <label class="form-label">Time</label>
            <select id="edit-time" class="form-control">
              <option value="09:00 AM" ${appt.time === '09:00 AM' ? 'selected' : ''}>09:00 AM</option>
              <option value="10:00 AM" ${appt.time === '10:00 AM' ? 'selected' : ''}>10:00 AM</option>
              <option value="11:15 AM" ${appt.time === '11:15 AM' ? 'selected' : ''}>11:15 AM</option>
              <option value="01:00 PM" ${appt.time === '01:00 PM' ? 'selected' : ''}>01:00 PM</option>
              <option value="02:30 PM" ${appt.time === '02:30 PM' ? 'selected' : ''}>02:30 PM</option>
              <option value="04:00 PM" ${appt.time === '04:00 PM' ? 'selected' : ''}>04:00 PM</option>
              <option value="05:30 PM" ${appt.time === '05:30 PM' ? 'selected' : ''}>05:30 PM</option>
              <option value="07:00 PM" ${appt.time === '07:00 PM' ? 'selected' : ''}>07:00 PM</option>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Status</label>
          <select id="edit-status" class="form-control">
            <option value="confirmed" ${appt.status === 'confirmed' ? 'selected' : ''}>Confirmed</option>
            <option value="completed" ${appt.status === 'completed' ? 'selected' : ''}>Completed</option>
            <option value="cancelled" ${appt.status === 'cancelled' ? 'selected' : ''}>Cancelled</option>
          </select>
        </div>

        <div style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 24px;">
          <button type="button" onclick="closeDashModal()" class="btn btn-outline">Cancel</button>
          <button type="submit" class="btn btn-gold">Save Changes</button>
        </div>
      </form>
    </div>
  `;

  setTimeout(() => modal.classList.add('active'), 10);
};

window.saveAppointmentEdits = function(e, id) {
  e.preventDefault();

  const services = typeof DEFAULT_SERVICES !== 'undefined' ? DEFAULT_SERVICES : [];
  const selectedServiceName = document.getElementById('edit-service').value;
  const serviceObj = services.find(s => s.name === selectedServiceName);

  const updatedFields = {
    fullName: document.getElementById('edit-name').value.trim(),
    service: selectedServiceName,
    servicePrice: serviceObj ? serviceObj.price : 0,
    preferredStaff: document.getElementById('edit-staff').value,
    date: document.getElementById('edit-date').value,
    time: document.getElementById('edit-time').value,
    status: document.getElementById('edit-status').value
  };

  updateAppointment(id, updatedFields);
  showToast(`Appointment ${id} updated successfully!`, 'success');
  closeDashModal();
  renderDashboard();
};

// Add Manual Booking Modal
function showAddBookingModal() {
  const services = typeof DEFAULT_SERVICES !== 'undefined' ? DEFAULT_SERVICES : [];
  const staffMembers = typeof DEFAULT_STAFF !== 'undefined' ? DEFAULT_STAFF : [];

  let modal = document.getElementById('dash-action-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'dash-action-modal';
    modal.className = 'modal-backdrop';
    document.body.appendChild(modal);
  }

  modal.innerHTML = `
    <div class="modal-box" style="max-width: 560px;">
      <button class="modal-close" onclick="closeDashModal()">&times;</button>
      <span class="section-subtitle">Staff Desk</span>
      <h3 style="font-size: 1.8rem; margin-bottom: 20px;">New Walk-in / Phone Reservation</h3>

      <form onsubmit="handleManualBookingSubmit(event)">
        <div class="form-group">
          <label class="form-label">Customer Name</label>
          <input type="text" id="manual-name" class="form-control" placeholder="e.g. Grace Kelly" required>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
          <div class="form-group">
            <label class="form-label">Phone Number</label>
            <input type="text" id="manual-phone" class="form-control" placeholder="+1 (555) 000-0000" required>
          </div>
          <div class="form-group">
            <label class="form-label">Email Address</label>
            <input type="email" id="manual-email" class="form-control" placeholder="grace@example.com" required>
          </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
          <div class="form-group">
            <label class="form-label">Service</label>
            <select id="manual-service" class="form-control" required>
              ${services.map(s => `<option value="${s.name}">[${s.category}] ${s.name} - ₹${s.price}</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Specialist</label>
            <select id="manual-staff" class="form-control">
              <option value="Any Available Specialist">Any Available Specialist</option>
              ${staffMembers.map(st => `<option value="${st.name}">${st.name}</option>`).join('')}
            </select>
          </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
          <div class="form-group">
            <label class="form-label">Date</label>
            <input type="date" id="manual-date" class="form-control" value="${new Date().toISOString().split('T')[0]}" required>
          </div>
          <div class="form-group">
            <label class="form-label">Time</label>
            <select id="manual-time" class="form-control">
              <option value="10:00 AM">10:00 AM</option>
              <option value="11:30 AM">11:30 AM</option>
              <option value="01:00 PM">01:00 PM</option>
              <option value="02:30 PM">02:30 PM</option>
              <option value="04:00 PM">04:00 PM</option>
              <option value="05:30 PM">05:30 PM</option>
            </select>
          </div>
        </div>

        <div style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 24px;">
          <button type="button" onclick="closeDashModal()" class="btn btn-outline">Cancel</button>
          <button type="submit" class="btn btn-gold">Create Booking</button>
        </div>
      </form>
    </div>
  `;

  setTimeout(() => modal.classList.add('active'), 10);
}

window.handleManualBookingSubmit = function(e) {
  e.preventDefault();

  const services = typeof DEFAULT_SERVICES !== 'undefined' ? DEFAULT_SERVICES : [];
  const serviceName = document.getElementById('manual-service').value;
  const serviceObj = services.find(s => s.name === serviceName);

  const randomCode = Math.floor(1000 + Math.random() * 9000);
  const bookingId = `LBS-2026-${randomCode}`;

  const newBooking = {
    id: bookingId,
    fullName: document.getElementById('manual-name').value.trim(),
    phone: document.getElementById('manual-phone').value.trim(),
    email: document.getElementById('manual-email').value.trim(),
    service: serviceName,
    servicePrice: serviceObj ? serviceObj.price : 0,
    preferredStaff: document.getElementById('manual-staff').value,
    date: document.getElementById('manual-date').value,
    time: document.getElementById('manual-time').value,
    notes: 'Manual booking created by staff desk.',
    status: 'confirmed',
    createdAt: new Date().toISOString()
  };

  addAppointment(newBooking);
  showToast(`Created booking ${bookingId}`, 'success');
  closeDashModal();
  renderDashboard();
};

window.closeDashModal = function() {
  const modal = document.getElementById('dash-action-modal');
  if (modal) modal.classList.remove('active');
};

// Google Sheet Integration Modal
function showGoogleSheetModal() {
  let modal = document.getElementById('dash-action-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'dash-action-modal';
    modal.className = 'modal-backdrop';
    document.body.appendChild(modal);
  }

  const currentUrl = getGoogleSheetUrl();

  modal.innerHTML = `
    <div class="modal-box" style="max-width: 680px; max-height: 90vh; overflow-y: auto;">
      <button class="modal-close" onclick="closeDashModal()">&times;</button>
      <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
        <div style="width: 36px; height: 36px; border-radius: 8px; background: rgba(16, 185, 129, 0.15); color: #10b981; display: flex; align-items: center; justify-content: center; font-size: 1.2rem;">
          <i data-lucide="file-spreadsheet"></i>
        </div>
        <div>
          <span class="section-subtitle" style="margin-bottom: 0;">Live Integration</span>
          <h3 style="font-size: 1.6rem;">Google Sheet Booking Sync</h3>
        </div>
      </div>
      <p style="font-size: 0.9rem; color: var(--text-muted); margin-bottom: 20px;">
        Connect your Google Sheet via Google Apps Script Web App to get booking details in real-time, fetch customer entries, or export all appointments.
      </p>

      <!-- Webhook Input Box -->
      <div class="glass-panel" style="padding: 20px; border-radius: var(--radius-md); margin-bottom: 24px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
          <label class="form-label" style="font-weight: 700; margin-bottom: 0;">
            <span>Google Apps Script Web App URL:</span>
          </label>
          <span style="font-size: 0.8rem; color: ${currentUrl ? '#10b981' : '#f59e0b'}; font-weight: 700; display: flex; align-items: center; gap: 4px;">
            ${currentUrl ? '● Connected & Active' : '○ Not Configured'}
          </span>
        </div>
        <div style="display: flex; gap: 10px; margin-bottom: 12px;">
          <input type="text" id="gsheet-url-input" class="form-control" value="${currentUrl}" placeholder="https://script.google.com/macros/s/.../exec">
          <button onclick="saveGoogleSheetUrlConfig()" class="btn btn-gold" style="white-space: nowrap;">Save URL</button>
        </div>
        <div style="display: flex; align-items: center; justify-content: space-between; font-size: 0.85rem; background: rgba(16, 185, 129, 0.08); padding: 10px 14px; border-radius: 6px; border: 1px solid rgba(16, 185, 129, 0.2);">
          <span style="color: var(--text-secondary); font-weight: 500;">
            <i data-lucide="sheet" style="width: 16px; display: inline; vertical-align: middle; color: #10b981;"></i> Connected Sheet: <strong>Luxe Beauty Studio Bookings</strong>
          </span>
          <a href="https://docs.google.com/spreadsheets/d/1AVPNsyQV8lj57HK1hPd6ZYd9OFKvOjLZfQtlC3mwn4k/edit?usp=sharing" target="_blank" class="btn btn-sm btn-gold" style="font-size: 0.75rem; padding: 4px 10px;">
            Open Google Sheet <i data-lucide="external-link"></i>
          </a>
        </div>
      </div>

      <!-- Action Buttons -->
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 24px;">
        <button onclick="triggerGetBookingsFromGSheet()" class="btn btn-gold" style="padding: 14px; text-align: center; justify-content: center;">
          <i data-lucide="download"></i> Get Bookings from Google Sheet
        </button>
        <button onclick="triggerPushAllToGSheet()" class="btn btn-outline" style="padding: 14px; border-color: var(--gold-primary); text-align: center; justify-content: center;">
          <i data-lucide="upload"></i> Sync All Local Bookings to Sheet
        </button>
      </div>

      <!-- Setup Guide & Apps Script Snippet -->
      <div style="border-top: 1px solid var(--border-subtle); padding-top: 20px;">
        <h4 style="font-size: 1.1rem; margin-bottom: 12px; display: flex; align-items: center; gap: 8px;">
          <i data-lucide="code" style="width: 18px; color: var(--gold-primary);"></i> Quick 2-Minute Google Apps Script Setup
        </h4>
        <ol style="font-size: 0.85rem; color: var(--text-secondary); margin-left: 20px; margin-bottom: 16px; line-height: 1.6;">
          <li>Create a Google Sheet & name it <strong>Luxe Beauty Studio Bookings</strong>.</li>
          <li>Click <strong>Extensions &gt; Apps Script</strong> from top menu bar.</li>
          <li>Paste the Google Apps Script code below and click <strong>Save</strong>.</li>
          <li>Click <strong>Deploy &gt; New deployment</strong> &rarr; Select <strong>Web app</strong> (Execute as: <i>Me</i>, Access: <i>Anyone</i>).</li>
          <li>Copy the Web App URL and paste it into the input box above.</li>
        </ol>

        <div style="position: relative;">
          <pre style="background: var(--bg-primary); padding: 14px; border-radius: var(--radius-md); font-family: monospace; font-size: 0.78rem; overflow-x: auto; border: 1px solid var(--border-subtle); max-height: 180px;" id="gsheet-code-block">
function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var data = JSON.parse(e.postData.contents);
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(["Booking ID", "Full Name", "Phone", "Email", "Service", "Price (₹)", "Specialist", "Date", "Time", "Notes", "Status", "Created At"]);
  }
  sheet.appendRow([
    data.id, data.fullName, data.phone, data.email, data.service,
    data.servicePrice, data.preferredStaff, data.date, data.time,
    data.notes, data.status, data.createdAt
  ]);
  return ContentService.createTextOutput(JSON.stringify({status: "success"})).setMimeType(ContentService.MimeType.JSON);
}

function doGet(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var rows = sheet.getDataRange().getValues();
  if (rows.length &lt;= 1) return ContentService.createTextOutput(JSON.stringify([])).setMimeType(ContentService.MimeType.JSON);
  
  var bookings = [];
  for (var i = 1; i &lt; rows.length; i++) {
    var r = rows[i];
    if (!r[0]) continue;
    bookings.push({
      id: r[0], fullName: r[1], phone: r[2], email: r[3],
      service: r[4], servicePrice: parseFloat(r[5]) || 0,
      preferredStaff: r[6], date: r[7], time: r[8],
      notes: r[9], status: r[10], createdAt: r[11]
    });
  }
  return ContentService.createTextOutput(JSON.stringify(bookings)).setMimeType(ContentService.MimeType.JSON);
}</pre>
          <button onclick="copyGSheetCodeSnippet()" class="btn btn-sm btn-outline" style="position: absolute; top: 10px; right: 10px; background: var(--bg-secondary); font-size: 0.75rem;">
            Copy Code
          </button>
        </div>
      </div>
    </div>
  `;

  setTimeout(() => {
    modal.classList.add('active');
    if (typeof lucide !== 'undefined') lucide.createIcons();
  }, 10);
}

window.saveGoogleSheetUrlConfig = function() {
  const input = document.getElementById('gsheet-url-input');
  if (input) {
    const val = input.value.trim();
    setGoogleSheetUrl(val);
    if (val) {
      showToast('Google Sheet Web App URL saved!', 'success');
    } else {
      showToast('Google Sheet URL cleared', 'info');
    }
  }
};

window.triggerGetBookingsFromGSheet = async function() {
  const url = getGoogleSheetUrl();
  if (!url) {
    showToast('Please enter and save your Google Apps Script Web App URL first.', 'error');
    return;
  }

  showToast('Fetching booking details from Google Sheet...', 'info');

  try {
    const res = await fetchFromGoogleSheet();
    if (res.success) {
      showToast(`Successfully synced! Total: ${res.count} bookings (${res.newCount} new added).`, 'success');
      closeDashModal();
      renderDashboard();
    }
  } catch (err) {
    showToast(`Google Sheet fetch error: ${err.message}`, 'error');
  }
};

window.triggerPushAllToGSheet = async function() {
  const url = getGoogleSheetUrl();
  if (!url) {
    showToast('Please enter and save your Google Apps Script Web App URL first.', 'error');
    return;
  }

  const appointments = getAppointments();
  if (appointments.length === 0) {
    showToast('No local appointments to sync.', 'info');
    return;
  }

  showToast(`Syncing ${appointments.length} local appointments to Google Sheet...`, 'info');

  let successCount = 0;
  for (const appt of appointments) {
    const ok = await syncToGoogleSheet(appt);
    if (ok) successCount++;
  }

  showToast(`Synced ${appointments.length} bookings to Google Sheet!`, 'success');
};

window.copyGSheetCodeSnippet = function() {
  const code = document.getElementById('gsheet-code-block').innerText;
  navigator.clipboard.writeText(code).then(() => {
    showToast('Google Apps Script code copied to clipboard!', 'success');
  }).catch(() => {
    showToast('Failed to copy. Please select manually.', 'error');
  });
};
