/* ============================================================
   LUXE BEAUTY STUDIO - GLOBAL APP SCRIPT
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  initScrollProgress();
  initStickyHeader();
  initScrollReveal();
  initCounters();
  initBackToTop();
  initMobileDrawer();
  initSearchModal();
  initPageLoader();
  setActiveNavLink();
});

/* Theme Switcher */
function initTheme() {
  const savedTheme = localStorage.getItem('luxe_theme') || 'light';
  document.documentElement.setAttribute('data-theme', savedTheme);
  updateThemeIcons(savedTheme);

  const themeToggleBtns = document.querySelectorAll('.theme-toggle-btn');
  themeToggleBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme');
      const next = current === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', next);
      localStorage.setItem('luxe_theme', next);
      updateThemeIcons(next);
    });
  });
}

function updateThemeIcons(theme) {
  const icons = document.querySelectorAll('.theme-toggle-btn i');
  icons.forEach(icon => {
    if (theme === 'dark') {
      icon.className = 'lucide-sun';
      icon.setAttribute('data-lucide', 'sun');
    } else {
      icon.className = 'lucide-moon';
      icon.setAttribute('data-lucide', 'moon');
    }
  });
  if (window.lucide) {
    window.lucide.createIcons();
  }
}

/* Scroll Progress Bar */
function initScrollProgress() {
  const progressBar = document.getElementById('scroll-progress');
  if (!progressBar) return;

  window.addEventListener('scroll', () => {
    const scrollTop = window.scrollY;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const scrolled = (scrollTop / docHeight) * 100;
    progressBar.style.width = scrolled + '%';
  });
}

/* Sticky Header */
function initStickyHeader() {
  const header = document.querySelector('.header');
  if (!header) return;

  window.addEventListener('scroll', () => {
    if (window.scrollY > 40) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  });
}

/* Scroll Reveal Observer */
function initScrollReveal() {
  const reveals = document.querySelectorAll('.reveal, .reveal-left, .reveal-right');
  if (!reveals.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('active');
      }
    });
  }, { threshold: 0.12 });

  reveals.forEach(el => observer.observe(el));
}

/* Animated Counters */
function initCounters() {
  const counters = document.querySelectorAll('.counter-val');
  if (!counters.length) return;

  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const target = +el.getAttribute('data-target');
        let count = 0;
        const speed = target / 50;

        const updateCount = () => {
          count += speed;
          if (count < target) {
            el.innerText = Math.ceil(count);
            setTimeout(updateCount, 25);
          } else {
            el.innerText = target + (el.getAttribute('data-suffix') || '');
          }
        };

        updateCount();
        obs.unobserve(el);
      }
    });
  }, { threshold: 0.5 });

  counters.forEach(c => observer.observe(c));
}

/* Back to Top */
function initBackToTop() {
  const btt = document.getElementById('back-to-top');
  if (!btt) return;

  window.addEventListener('scroll', () => {
    if (window.scrollY > 400) {
      btt.classList.add('visible');
    } else {
      btt.classList.remove('visible');
    }
  });

  btt.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

/* Mobile Drawer Menu */
function initMobileDrawer() {
  const toggle = document.querySelector('.mobile-nav-toggle');
  const drawer = document.getElementById('mobile-drawer');
  const closeBtn = document.getElementById('drawer-close');

  if (!toggle || !drawer) return;

  toggle.addEventListener('click', () => {
    drawer.classList.add('open');
  });

  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      drawer.classList.remove('open');
    });
  }

  drawer.addEventListener('click', (e) => {
    if (e.target === drawer) {
      drawer.classList.remove('open');
    }
  });
}

/* Search Modal */
function initSearchModal() {
  const searchTriggers = document.querySelectorAll('.open-search-modal');
  const searchModal = document.getElementById('search-modal');
  const searchInput = document.getElementById('search-modal-input');
  const searchResults = document.getElementById('search-modal-results');
  const closeBtn = document.getElementById('search-modal-close');

  if (!searchModal) return;

  searchTriggers.forEach(btn => {
    btn.addEventListener('click', () => {
      searchModal.classList.add('active');
      if (searchInput) searchInput.focus();
    });
  });

  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      searchModal.classList.remove('active');
    });
  }

  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      const query = e.target.value.toLowerCase().trim();
      if (!query) {
        searchResults.innerHTML = '<p class="text-muted">Type to search services, prices, or staff...</p>';
        return;
      }

      const services = typeof DEFAULT_SERVICES !== 'undefined' ? DEFAULT_SERVICES : [];
      const matches = services.filter(s => 
        s.name.toLowerCase().includes(query) || 
        s.category.toLowerCase().includes(query) ||
        s.desc.toLowerCase().includes(query)
      );

      if (matches.length === 0) {
        searchResults.innerHTML = '<p class="text-muted">No matching services found.</p>';
      } else {
        searchResults.innerHTML = matches.map(s => `
          <div style="padding: 12px; border-bottom: 1px solid var(--border-subtle); display: flex; justify-content: space-between; align-items: center;">
            <div>
              <h5 style="font-size: 1.1rem; margin-bottom: 4px;">${s.name}</h5>
              <span style="font-size: 0.8rem; color: var(--gold-primary); font-weight: 600;">${s.category} • ${s.duration}</span>
            </div>
            <div style="text-align: right;">
              <span style="font-family: var(--font-serif); font-weight: 600; font-size: 1.2rem; color: var(--gold-primary);">₹${s.price}</span>
              <div><a href="appointment.html?service=${encodeURIComponent(s.name)}" class="btn btn-sm btn-gold" style="padding: 4px 12px; font-size: 0.75rem; margin-top: 4px;">Book</a></div>
            </div>
          </div>
        `).join('');
      }
    });
  }
}

/* Page Loader */
function initPageLoader() {
  const loader = document.getElementById('page-loader');
  if (loader) {
    setTimeout(() => {
      loader.classList.add('hidden');
    }, 400);
  }
}

/* Highlight Active Nav Link */
function setActiveNavLink() {
  const currentPath = window.location.pathname.split('/').pop() || 'index.html';
  const navLinks = document.querySelectorAll('.nav-link, .mobile-menu-link');
  
  navLinks.forEach(link => {
    const href = link.getAttribute('href');
    if (href === currentPath || (currentPath === '' && href === 'index.html')) {
      link.classList.add('active');
    }
  });
}
