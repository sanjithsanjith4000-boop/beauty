/* ============================================================
   LUXE BEAUTY STUDIO - STAFF AUTHENTICATION (STAFF.JS)
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {
  initStaffLogin();
});

// Google Sheet URL
const GOOGLE_SHEET_URL = "https://docs.google.com/spreadsheets/d/1AVPNsyQV8lj57HK1hPd6ZYd9OFKvOjLZfQtlC3mwn4k/edit?usp=sharing";

// Demo Credentials
const DEMO_STAFF_USERS = [
  {
    id: 'STF-1001',
    name: 'Elena Rostova',
    role: 'Master Stylist & Admin',
    password: '2108'
  },
  {
    id: 'STF-1002',
    name: 'Sophia Chen',
    role: 'Senior Bridal Specialist',
    password: '2108'
  },
  {
    id: 'STF-1003',
    name: 'Isabella Vance',
    role: 'Therapist',
    password: '2108'
  }
];

function initStaffLogin() {

  const loginForm = document.getElementById('staff-login-form');
  const staffIdInput = document.getElementById('staff-id');
  const passwordInput = document.getElementById('staff-password');
  const togglePassBtn = document.getElementById('toggle-password');
  const rememberCheckbox = document.getElementById('remember-me');

  if (!loginForm) return;

  // Remember Staff ID
  const savedStaffId = localStorage.getItem('luxe_remembered_staff_id');

  if (savedStaffId && staffIdInput) {
    staffIdInput.value = savedStaffId;
    rememberCheckbox.checked = true;
  }

  // Show / Hide Password
  if (togglePassBtn && passwordInput) {

    togglePassBtn.addEventListener('click', () => {

      if (passwordInput.type === "password") {
        passwordInput.type = "text";
        togglePassBtn.innerText = "Hide";
      } else {
        passwordInput.type = "password";
        togglePassBtn.innerText = "Show";
      }

    });

  }

  // Quick Login Button
  window.fillDemoCredentials = function(id, pass) {

    if (staffIdInput)
      staffIdInput.value = id || "STF-1001";

    if (passwordInput)
      passwordInput.value = pass || "2108";

    if (typeof showToast === "function") {
      showToast("PIN 2108 Applied", "info");
    }

  };

  // Login
  loginForm.addEventListener("submit", function(e) {

    e.preventDefault();

    const staffId = staffIdInput.value.trim() || "STF-1001";
    const password = passwordInput.value.trim();

    if (password === "") {

      if (typeof showToast === "function") {
        showToast("Please enter Staff PIN", "error");
      } else {
        alert("Please enter Staff PIN");
      }

      passwordInput.focus();
      return;
    }

    // PIN Verification
    if (password === "2108") {

      const user =
        DEMO_STAFF_USERS.find(
          u => u.id.toLowerCase() === staffId.toLowerCase()
        ) || DEMO_STAFF_USERS[0];

      // Remember Me
      if (rememberCheckbox.checked) {
        localStorage.setItem(
          "luxe_remembered_staff_id",
          user.id
        );
      } else {
        localStorage.removeItem(
          "luxe_remembered_staff_id"
        );
      }

      // Save Login Session
      if (typeof STORAGE_KEYS !== "undefined") {

        localStorage.setItem(
          STORAGE_KEYS.STAFF_USER,
          JSON.stringify({
            id: user.id,
            name: user.name,
            role: user.role,
            loggedInAt: new Date().toISOString()
          })
        );

      }

      if (typeof showToast === "function") {
        showToast(
          "PIN Verified! Opening Booking Details...",
          "success"
        );
      }

      // Open Google Sheet after login
      setTimeout(() => {

        // Same Tab
        window.location.href = GOOGLE_SHEET_URL;

        // If you want New Tab instead, use:
        // window.open(GOOGLE_SHEET_URL, "_blank");

      }, 500);

    } else {

      if (typeof showToast === "function") {
        showToast(
          "Invalid PIN! Please enter 2108.",
          "error"
        );
      } else {
        alert("Invalid PIN!");
      }

    }

  });

}