/* ============================================================
   LUXE BEAUTY STUDIO - LOCAL STORAGE SEED & DATA ENGINE
   ============================================================ */

const STORAGE_KEYS = {
  APPOINTMENTS: 'luxe_appointments',
  STAFF_USER: 'luxe_staff_user',
  SERVICES: 'luxe_services',
  STAFF_MEMBERS: 'luxe_staff_members',
  THEME: 'luxe_theme',
  GSHEET_URL: 'luxe_gsheet_url'
};

// Initial Services List
const DEFAULT_SERVICES = [
  { id: 's1', name: 'Hair Cut', category: 'Hair', price: 600, duration: '45 mins', desc: 'Precision styling, split-end trim & luxury blow dry finish.' },
  { id: 's2', name: 'Hair Coloring', category: 'Hair', price: 1500, duration: '120 mins', desc: 'Global color, balayage, highlights or root touch-up with rich gloss.' },
  { id: 's3', name: 'Hair Spa', category: 'Hair', price: 900, duration: '60 mins', desc: 'Nourishing botanical hair mask, scalp massage & steam therapy.' },
  { id: 's4', name: 'Keratin Treatment', category: 'Hair', price: 2200, duration: '150 mins', desc: 'Frizz-free, ultra-smooth silky hair lock transformation.' },
  { id: 's5', name: 'Smoothening', category: 'Hair', price: 2000, duration: '150 mins', desc: 'Long-lasting straightness with thermal hair protection.' },
  { id: 's6', name: 'Hydra Facial', category: 'Facial', price: 1300, duration: '60 mins', desc: 'Deep exfoliation, pore vacuuming & hyaluronic serum infusion.' },
  { id: 's7', name: 'Cleanup', category: 'Facial', price: 500, duration: '30 mins', desc: 'Instant glow cleanup, blackhead removal & soothing mask.' },
  { id: 's8', name: 'Detan', category: 'Facial', price: 650, duration: '40 mins', desc: 'Brightening detan therapy for face, neck, and shoulders.' },
  { id: 's9', name: 'Bridal Makeup', category: 'Makeup', price: 4500, duration: '180 mins', desc: 'HD Waterproof luxury bridal makeup with lashes & dupatta setting.' },
  { id: 's10', name: 'Party Makeup', category: 'Makeup', price: 1600, duration: '90 mins', desc: 'Glamorous event makeup, contouring & long-wear setting.' },
  { id: 's11', name: 'Engagement Makeup', category: 'Makeup', price: 2800, duration: '120 mins', desc: 'Subtle royal elegance makeup tailored for engagement brides.' },
  { id: 's12', name: 'Threading', category: 'Essentials', price: 150, duration: '15 mins', desc: 'Eyebrow shaping, upper lip, chin, or full face precision threading.' },
  { id: 's13', name: 'Waxing', category: 'Essentials', price: 750, duration: '45 mins', desc: 'Painless organic chocolate or Rica full body/arms/legs waxing.' },
  { id: 's14', name: 'Manicure', category: 'Nails & Spa', price: 450, duration: '45 mins', desc: 'Cuticle care, hand exfoliation massage & chip-free polish.' },
  { id: 's15', name: 'Pedicure', category: 'Nails & Spa', price: 550, duration: '50 mins', desc: 'Relaxing foot soak, scrub, calloused skin care & gel color.' },
  { id: 's16', name: 'Nail Art', category: 'Nails & Spa', price: 400, duration: '30 mins', desc: 'Hand-painted metallic accents, chrome, or rhinestone designs.' },
  { id: 's17', name: 'Eyelash Extension', category: 'Lashes & Brows', price: 1100, duration: '90 mins', desc: 'Weightless silk/mink lash extensions (Classic, Hybrid or Volume).' }
];

// Initial Staff List
const DEFAULT_STAFF = [
  { id: 'st1', name: 'Elena Rostova', role: 'Master Stylist & Colorist', experience: '12+ Years' },
  { id: 'st2', name: 'Sophia Chen', role: 'Senior Bridal Makeup Artist', experience: '10+ Years' },
  { id: 'st3', name: 'Isabella Vance', role: 'Skincare & Hydra Facial Specialist', experience: '8+ Years' },
  { id: 'st4', name: 'Maya Patel', role: 'Master Nail & Lash Designer', experience: '7+ Years' },
  { id: 'st5', name: 'Liam Reynolds', role: 'Hair Spa & Keratin Specialist', experience: '9+ Years' }
];

// Default Initial Seed Appointments
const DEFAULT_APPOINTMENTS = [
  {
    id: 'LBS-2026-8812',
    fullName: 'Camilla Montgomery',
    phone: '+91 98424 23456',
    email: 'camilla@example.com',
    service: 'Bridal Makeup',
    servicePrice: 4500,
    preferredStaff: 'Sophia Chen',
    date: '2026-07-30',
    time: '10:00 AM',
    notes: 'Requires airbrush HD makeup and dupatta setting.',
    status: 'confirmed',
    createdAt: '2026-07-28T10:15:00Z'
  },
  {
    id: 'LBS-2026-9431',
    fullName: 'Victoria Sterling',
    phone: '+91 98424 98765',
    email: 'victoria@example.com',
    service: 'Hydra Facial',
    servicePrice: 1300,
    preferredStaff: 'Isabella Vance',
    date: '2026-07-30',
    time: '02:30 PM',
    notes: 'Sensitive skin type.',
    status: 'confirmed',
    createdAt: '2026-07-29T08:30:00Z'
  },
  {
    id: 'LBS-2026-1042',
    fullName: 'Seraphina Rossi',
    phone: '+91 98424 34567',
    email: 'seraphina@example.com',
    service: 'Keratin Treatment',
    servicePrice: 2200,
    preferredStaff: 'Elena Rostova',
    date: '2026-07-31',
    time: '11:15 AM',
    notes: 'Thick wavy hair.',
    status: 'confirmed',
    createdAt: '2026-07-29T14:20:00Z'
  },
  {
    id: 'LBS-2026-0211',
    fullName: 'Amara Jackson',
    phone: '+91 98424 45678',
    email: 'amara@example.com',
    service: 'Eyelash Extension',
    servicePrice: 1100,
    preferredStaff: 'Maya Patel',
    date: '2026-07-28',
    time: '04:00 PM',
    notes: 'Volume set requested.',
    status: 'completed',
    createdAt: '2026-07-27T11:00:00Z'
  },
  {
    id: 'LBS-2026-0089',
    fullName: 'Genevieve Laurent',
    phone: '+91 98424 67890',
    email: 'genevieve@example.com',
    service: 'Party Makeup',
    servicePrice: 1600,
    preferredStaff: 'Sophia Chen',
    date: '2026-07-27',
    time: '05:00 PM',
    notes: 'Evening gala event.',
    status: 'completed',
    createdAt: '2026-07-26T09:40:00Z'
  }
];

// Initialize Storage Engine
function initStorage() {
  if (!localStorage.getItem(STORAGE_KEYS.SERVICES)) {
    localStorage.setItem(STORAGE_KEYS.SERVICES, JSON.stringify(DEFAULT_SERVICES));
  }
  if (!localStorage.getItem(STORAGE_KEYS.STAFF_MEMBERS)) {
    localStorage.setItem(STORAGE_KEYS.STAFF_MEMBERS, JSON.stringify(DEFAULT_STAFF));
  }
  if (!localStorage.getItem(STORAGE_KEYS.APPOINTMENTS)) {
    localStorage.setItem(STORAGE_KEYS.APPOINTMENTS, JSON.stringify(DEFAULT_APPOINTMENTS));
  }
}

// Get Appointments
function getAppointments() {
  initStorage();
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.APPOINTMENTS)) || [];
  } catch (e) {
    return DEFAULT_APPOINTMENTS;
  }
}

// Save Appointments
function saveAppointments(appointments) {
  localStorage.setItem(STORAGE_KEYS.APPOINTMENTS, JSON.stringify(appointments));
}

// Add Single Appointment
function addAppointment(bookingData) {
  const appointments = getAppointments();
  appointments.unshift(bookingData);
  saveAppointments(appointments);
  
  // Auto-Sync to Google Sheet if configured
  syncToGoogleSheet(bookingData).catch(err => console.log('Google Sheet auto-sync notice:', err));

  return bookingData;
}

// Update Appointment Status/Details
function updateAppointment(id, updatedFields) {
  const appointments = getAppointments();
  const index = appointments.findIndex(a => a.id === id);
  if (index !== -1) {
    appointments[index] = { ...appointments[index], ...updatedFields };
    saveAppointments(appointments);
    syncToGoogleSheet(appointments[index]).catch(err => console.log('Google Sheet sync notice:', err));
    return appointments[index];
  }
  return null;
}

// Delete Appointment
function deleteAppointment(id) {
  let appointments = getAppointments();
  appointments = appointments.filter(a => a.id !== id);
  saveAppointments(appointments);
}

// ============================================================
// GOOGLE SHEETS INTEGRATION ENGINE (HTML/CSS/JS ONLY)
// ============================================================

// Configured Google Apps Script Web App URL provided by user
const DEFAULT_GSHEET_WEB_APP_URL = 'https://script.google.com/macros/s/AKfycbyNHqOvCSEs2gut4DqY1YVyvNxhc2pEd1DftrZILIMVKUEUZJcTqzFGezxBlusZ2Ukwsg/exec';

function getGoogleSheetUrl() {
  return localStorage.getItem(STORAGE_KEYS.GSHEET_URL) || DEFAULT_GSHEET_WEB_APP_URL;
}

function setGoogleSheetUrl(url) {
  if (url) {
    localStorage.setItem(STORAGE_KEYS.GSHEET_URL, url.trim());
  } else {
    localStorage.removeItem(STORAGE_KEYS.GSHEET_URL);
  }
}

// Send single booking to Google Sheet (POST)
async function syncToGoogleSheet(booking) {
  const url = getGoogleSheetUrl();
  if (!url) {
    console.log('No Google Sheet URL set yet. Booking saved locally.');
    return false;
  }

  try {
    const response = await fetch(url, {
      method: 'POST',
      mode: 'no-cors',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(booking)
    });
    console.log('Booking submitted to Google Sheet successfully');
    return true;
  } catch (error) {
    console.warn('Could not post to Google Sheet:', error);
    return false;
  }
}

// Get/Fetch booking details from Google Sheet (GET)
async function fetchFromGoogleSheet() {
  const url = getGoogleSheetUrl();
  if (!url) {
    throw new Error('Please enter your Google Apps Script Web App URL first.');
  }

  // Append action param to avoid caching
  const fetchUrl = url.includes('?') ? `${url}&action=get_bookings&t=${Date.now()}` : `${url}?action=get_bookings&t=${Date.now()}`;
  
  const response = await fetch(fetchUrl);
  if (!response.ok) {
    throw new Error(`Google Sheet returned HTTP ${response.status}`);
  }
  
  const data = await response.json();
  if (Array.isArray(data) && data.length > 0) {
    // Merge fetched bookings with existing appointments
    const localAppointments = getAppointments();
    const existingIds = new Set(localAppointments.map(a => a.id));

    let addedCount = 0;
    data.forEach(item => {
      if (item && item.id && !existingIds.has(item.id)) {
        localAppointments.push(item);
        existingIds.add(item.id);
        addedCount++;
      }
    });

    saveAppointments(localAppointments);
    return { success: true, count: data.length, newCount: addedCount, bookings: localAppointments };
  } else if (Array.isArray(data)) {
    return { success: true, count: 0, newCount: 0, bookings: getAppointments() };
  } else {
    throw new Error('Invalid JSON format received from Google Sheet Apps Script');
  }
}

// Run Initialization on Load
initStorage();
