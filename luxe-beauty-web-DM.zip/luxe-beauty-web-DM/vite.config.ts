import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig({
  build: {
    rollupOptions: {
      input: {
        main: path.resolve(__dirname, 'index.html'),
        about: path.resolve(__dirname, 'about.html'),
        services: path.resolve(__dirname, 'services.html'),
        gallery: path.resolve(__dirname, 'gallery.html'),
        pricing: path.resolve(__dirname, 'pricing.html'),
        offers: path.resolve(__dirname, 'offers.html'),
        testimonials: path.resolve(__dirname, 'testimonials.html'),
        team: path.resolve(__dirname, 'team.html'),
        appointment: path.resolve(__dirname, 'appointment.html'),
        contact: path.resolve(__dirname, 'contact.html'),
        staffLogin: path.resolve(__dirname, 'staff-login.html'),
        staffDashboard: path.resolve(__dirname, 'staff-dashboard.html'),
      },
    },
  },
  server: {
    hmr: process.env.DISABLE_HMR !== 'true',
    watch: process.env.DISABLE_HMR === 'true' ? null : {},
  },
});
